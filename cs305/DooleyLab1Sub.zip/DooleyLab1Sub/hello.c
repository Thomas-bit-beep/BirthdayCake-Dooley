/* Tyson Dooley */
#include <stdio.h>

/* main program prints Hello, world! */
int main(int argc, char* argv[]){
    printf("Hello, world!\n");
    for (int i = 0; i <= 50; i++) {
        printf("I love C\n");
    }
    return 0;
}